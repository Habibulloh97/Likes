function Like(){
    like= document.querySelector("#like");
    like.innerHTML= parseInt(like.textContent)+1
}