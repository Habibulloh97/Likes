function Like1(){
    like= document.querySelector("#like1");
    like.innerHTML= parseInt(like.textContent)+1
}

function Like2(){
    like= document.querySelector("#like2");
    like.innerHTML= parseInt(like.textContent)+1
}

function Like3(){
    like= document.querySelector("#like3");
    like.innerHTML= parseInt(like.textContent)+1
}